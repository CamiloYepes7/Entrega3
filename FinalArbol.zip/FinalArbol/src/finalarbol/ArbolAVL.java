/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalarbol;

import java.util.Scanner;

/**
 * Clase que representa un nodo en el árbol AVL.
 */
class Nodo {
    int id;
    String nombre;
    int altura;
    Nodo izquierda, derecha;

    // Constructor de la clase Nodo
    Nodo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        altura = 1; // Inicialmente la altura es 1 para un nuevo nodo
    }
}

/**
 * Clase que implementa un árbol AVL.
 */
public class ArbolAVL {
    Nodo raiz; // Raíz del árbol AVL

    // Método para obtener la altura de un nodo
    int altura(Nodo N) {
        if (N == null) return 0; // Si el nodo es nulo, la altura es 0
        return N.altura;
    }

    // Método para obtener el factor de balance de un nodo
    int balance(Nodo N) {
        if (N == null) return 0; // Si el nodo es nulo, el balance es 0
        return altura(N.izquierda) - altura(N.derecha); // Diferencia de alturas de los subárboles izquierdo y derecho
    }

    // Rotación a la derecha
    Nodo rotacionDerecha(Nodo y) {
        Nodo x = y.izquierda;
        Nodo T2 = x.derecha;

        // Realizar la rotación
        x.derecha = y;
        y.izquierda = T2;

        // Actualizar alturas
        y.altura = Math.max(altura(y.izquierda), altura(y.derecha)) + 1;
        x.altura = Math.max(altura(x.izquierda), altura(x.derecha)) + 1;

        return x; // Retornar la nueva raíz
    }

    // Rotación a la izquierda
    Nodo rotacionIzquierda(Nodo x) {
        Nodo y = x.derecha;
        Nodo T2 = y.izquierda;

        // Realizar la rotación
        y.izquierda = x;
        x.derecha = T2;

        // Actualizar alturas
        x.altura = Math.max(altura(x.izquierda), altura(x.derecha)) + 1;
        y.altura = Math.max(altura(y.izquierda), altura(y.derecha)) + 1;

        return y; // Retornar la nueva raíz
    }

    // Insertar un nodo en el árbol AVL
    Nodo insertar(Nodo nodo, int id, String nombre) {
        if (nodo == null) return (new Nodo(id, nombre)); // Si el nodo es nulo, crear un nuevo nodo

        // Insertar en el subárbol izquierdo o derecho según el valor del nodo
        if (id < nodo.id) nodo.izquierda = insertar(nodo.izquierda, id, nombre);
        else if (id > nodo.id) nodo.derecha = insertar(nodo.derecha, id, nombre);
        else return nodo; // No se permiten duplicados

        // Actualizar la altura del nodo actual
        nodo.altura = 1 + Math.max(altura(nodo.izquierda), altura(nodo.derecha));

        // Calcular el factor de balance del nodo actual
        int balance = balance(nodo);

        // Casos de rotaciones para mantener el balance
        if (balance > 1 && id < nodo.izquierda.id) return rotacionDerecha(nodo);
        if (balance < -1 && id > nodo.derecha.id) return rotacionIzquierda(nodo);
        if (balance > 1 && id > nodo.izquierda.id) {
            nodo.izquierda = rotacionIzquierda(nodo.izquierda);
            return rotacionDerecha(nodo);
        }
        if (balance < -1 && id < nodo.derecha.id) {
            nodo.derecha = rotacionDerecha(nodo.derecha);
            return rotacionIzquierda(nodo);
        }

        return nodo; // Retornar el nodo actualizado
    }

    // Encontrar el nodo con el valor mínimo en un subárbol
    Nodo encontrarMinimo(Nodo nodo) {
        Nodo actual = nodo;

        while (actual.izquierda != null) actual = actual.izquierda;

        return actual; // Retornar el nodo mínimo
    }

    // Eliminar un nodo del árbol AVL
    Nodo eliminarNodo(Nodo raiz, int id) {
        if (raiz == null) return raiz; // Si la raíz es nula, retornarla

        // Buscar el nodo a eliminar en el subárbol izquierdo o derecho
        if (id < raiz.id) raiz.izquierda = eliminarNodo(raiz.izquierda, id);
        else if (id > raiz.id) raiz.derecha = eliminarNodo(raiz.derecha, id);
        else {
            // Nodo con solo un hijo o sin hijos
            if (raiz.izquierda == null || raiz.derecha == null) {
                Nodo temp = null;
                if (temp == raiz.izquierda) temp = raiz.derecha;
                else temp = raiz.izquierda;

                // Nodo sin hijos
                if (temp == null) {
                    temp = raiz;
                    raiz = null;
                } else // Nodo con un hijo
                    raiz = temp;
            } else {
                // Nodo con dos hijos: Obtener el sucesor en inorden (menor en el subárbol derecho)
                Nodo temp = encontrarMinimo(raiz.derecha);

                // Copiar los datos del sucesor en inorden al nodo actual
                raiz.id = temp.id;
                raiz.nombre = temp.nombre;

                // Eliminar el sucesor en inorden
                raiz.derecha = eliminarNodo(raiz.derecha, temp.id);
            }
        }

        if (raiz == null) return raiz; // Si la raíz es nula, retornarla

        // Actualizar la altura de la raíz y calcular el factor de balance
        raiz.altura = Math.max(altura(raiz.izquierda), altura(raiz.derecha)) + 1;
        int balance = balance(raiz);

        // Casos de rotaciones para mantener el balance
        if (balance > 1 && balance(raiz.izquierda) >= 0) return rotacionDerecha(raiz);
        if (balance < -1 && balance(raiz.derecha) <= 0) return rotacionIzquierda(raiz);
        if (balance > 1 && balance(raiz.izquierda) < 0) {
            raiz.izquierda = rotacionIzquierda(raiz.izquierda);
            return rotacionDerecha(raiz);
        }
        if (balance < -1 && balance(raiz.derecha) > 0) {
            raiz.derecha = rotacionDerecha(raiz.derecha);
            return rotacionIzquierda(raiz);
        }

        return raiz; // Retornar la raíz actualizada
    }

    // Buscar un nodo en el árbol AVL
    boolean buscar(Nodo nodo, int id) {
        if (nodo == null) return false; // Si el nodo es nulo, no se encontró
        if (id == nodo.id) return true; // Si el nodo actual tiene el id buscado, se encontró
        if (id < nodo.id) return buscar(nodo.izquierda, id); // Buscar en el subárbol izquierdo
        return buscar(nodo.derecha, id); // Buscar en el subárbol derecho
    }

    // Recorrido preorden para mostrar el árbol AVL
    void preOrden(Nodo nodo) {
        if (nodo != null) {
            System.out.println(nodo.id + " - " + nodo.nombre); // Mostrar el nodo actual
            preOrden(nodo.izquierda); // Recorrer el subárbol izquierdo
            preOrden(nodo.derecha); // Recorrer el subárbol derecho
        }
    }

    // Método para mostrar el árbol AVL en formato preorden
   public void mostrar() {
    mostrarArbol(raiz, "");
}

private void mostrarArbol(Nodo nodo, String prefijo) {
    if (nodo != null) {
        System.out.println(prefijo + "|-- " + nodo.id + " - " + nodo.nombre);
        mostrarArbol(nodo.izquierda, prefijo + "|   ");
        mostrarArbol(nodo.derecha, prefijo + "|   ");
    }
}
  public static void main(String[] args) {
        ArbolAVL arbol = new ArbolAVL();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nOpciones:");
            System.out.println("1. Insertar nodo");
            System.out.println("2. Buscar nodo");
            System.out.println("3. Eliminar nodo");
            System.out.println("4. Mostrar árbol");
            System.out.println("5. Encontrar el nodo con el valor mínimo");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el id del nodo: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea
                    System.out.print("Ingrese el nombre del nodo: ");
                    String nombre = scanner.nextLine();
                    arbol.raiz = arbol.insertar(arbol.raiz, id, nombre);
                    break;

                case 2:
                    System.out.print("Ingrese el id del nodo a buscar: ");
                    int idBuscar = scanner.nextInt();
                    if (arbol.buscar(arbol.raiz, idBuscar)) {
                        System.out.println("Nodo encontrado.");
                    } else {
                        System.out.println("Nodo no encontrado.");
                    }
                    break;

                case 3:
                    System.out.print("Ingrese el id del nodo a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    arbol.raiz = arbol.eliminarNodo(arbol.raiz, idEliminar);
                    break;

                case 4:
                    System.out.println("El árbol AVL en preorden es:");
                    arbol.mostrar();
                    break;

                case 5:
                    Nodo minimo = arbol.encontrarMinimo(arbol.raiz);
                    if (minimo != null) {
                        System.out.println("El nodo con el valor mínimo es: " + minimo.id + " - " + minimo.nombre);
                    } else {
                        System.out.println("El árbol está vacío.");
                    }
                    break;

                case 6:
                    System.out.println("Saliendo del programa...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }
}